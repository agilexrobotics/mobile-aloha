# rs-benchmark Tool

## Goal
The goal of this tool is to benchmark the performance of various `librealsense` processing blocks.
Results of the benchmark depend on the camera being used and the setup.

## Usage


## Command Line Parameters

|Flag   |Description   |
|---|---|



